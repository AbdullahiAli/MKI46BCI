%% Initialisation

% Change directory
try cd(fileparts(mfilename('fullpath')));catch; end;   
% Initialise paths
try
   run ../../matlab/utilities/initPaths.m
catch
   msgbox({'Please change to the directory where this file is saved before running the rest of this code'},'Change directory'); 
end

buffhost='localhost';buffport=1972;
% Wait for the buffer to return valid header information
hdr=[];
while ( isempty(hdr) || ~isstruct(hdr) || (hdr.nchans==0) ) % wait for the buffer to contain valid data
  try 
    hdr=buffer('get_hdr',[],buffhost,buffport); 
  catch
    hdr=[];
    fprintf('Invalid header info... waiting.\n');
  end;
  pause(1);
end;

% Set the real-time-clock to use
initgetwTime;
initsleepSec;

% Settings
alphabet = char({'ABCDEFGHIJKLMNOPQRSTUVWXYZ'});
cueDuration = 2;                % Time the cue appears on screen
interClearDuration = 1;         % Time the screen is blank between cue and targets
interLetterDuration = 0.1;      % Time every target is shown

%% Own code / Calibration

% Make the stimulus, i.e. put a text box in the middle of the axes
clf;
set(gcf,'color',[0 0 0],'toolbar','none','menubar','none'); % black figure
set(gca,'visible','off','color',[0 0 0]); % black axes
h=text(.5,.5,'text','HorizontalAlignment','center','VerticalAlignment','middle',...
       'FontUnits','normalized','fontsize',.2,'color',[1 1 1],'visible','off'); 
   
% Press button to start the sequence
msg=msgbox({'Press OK to start'},'Start?');while ishandle(msg); pause(.2); end;
sendEvent('stimulus.sequence','start'); % Send start sequence event

% Run the calibration sequence
for i = 1:10
    
    % Show cue
    set(h,'string','Think of your target letter and get-ready','color', 'gr', 'visible', 'on');   % Dislplay target
    drawnow;                                                 % Redraw display
    sendEvent('stimulus.cue', 'cue');                        % Send event with target value
    sleepSec(cueDuration);                                   % Do nothing for 2 seconds
    
    % Clear screen for 1 second 
    set(h,'string','', 'visible', 'on');                     % Set empty target so there's nothing to display
    drawnow;                                                 % Redraw display
    sendEvent('stimulus.cleardisplay', 'clear');             % Send event for end of cue display
    sleepSec(interClearDuration);                            % Do nothing for 1 second
    
    % Show all letters for 0.1 second
    sendEvent('stimulus.target', 'start');                   % Send event for begin of target runs
    for j = 1:5
        alphabet = alphabet(randperm(length(alphabet)));     % Reorder the alphabet
        for k = 1:length(alphabet)
            set(h,'string',alphabet(k), 'color', [1 1 1], 'visible', 'on'); % Show the letter
            drawnow;                                                        % Redraw display
            % Send event with target information
            sendEvent('stimulus.letter',alphabet(k));        % Send event with letter information
            sleepSec(interLetterDuration);                   % Sleep for 0.1 second
        end
    end
    sendEvent('stimulus.target', 'stop');                    % Send event for end of target runs
    
    % Clear screen for 1 second 
    set(h,'string','', 'visible', 'on');                     % Set empty target so there's nothing to display
    drawnow;                                                 % Redraw display
    sendEvent('stimulus.cleardisplay', 'clear');             % Send event for end of cue display
    sleepSec(interClearDuration);                            % Do nothing for 1 second
    
    % Show prediction for 2 seconds
    [devents,state]=buffer_newevents(buffhost,buffport,[],{'classifier.prediction'},{},2000);    % Get predictions from classifier
    set(h,'string',devents(1).value,'color', 'bl','visible','on');                               % Set display to predicted target
    drawnow;                                                 % Redraw the display
    sendEvent('stimulus.prediction',devents(1).value);       % Send event with prediction information
    sleepSec(cueDuration);                                   % Sleep for 2 seconds
    
    
    % Clear screen for 1 second 
    set(h,'string','', 'visible', 'on');                     % Set empty target so there's nothing to display
    drawnow;                                                 % Redraw display
    sendEvent('stimulus.cleardisplay', 'clear');             % Send event for end of cue display
    sleepSec(interClearDuration);                            % Do nothing for 1 second
    
end
sendEvent('stimulus.sequence','stop');                       % Send event for end of sequence