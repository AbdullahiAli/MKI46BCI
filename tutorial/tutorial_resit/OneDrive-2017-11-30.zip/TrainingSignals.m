%% Initialisation

% Change directory
try cd(fileparts(mfilename('fullpath')));catch; end;   
% Initialise paths
try
   run ../../matlab/utilities/initPaths.m
catch
   msgbox({'Please change to the directory where this file is saved before running the rest of this code'},'Change directory'); 
end

buffhost='localhost';buffport=1972;
% Wait for the buffer to return valid header information
hdr=[];
while ( isempty(hdr) || ~isstruct(hdr) || (hdr.nchans==0) ) % wait for the buffer to contain valid data
  try 
    hdr=buffer('get_hdr',[],buffhost,buffport); 
  catch
    hdr=[];
    fprintf('Invalid header info... waiting.\n');
  end;
  pause(1);
end;

% Settings
capFile='cap_tmsi_mobita_im.txt';   % The capfile that was used to record data
dname  ='training_data';            % Name of the document to store data to
clsfrname = 'classifier';           % Name of the classifier

% Load data
load(dname);

%% Train classifier
clsfr=buffer_train_erp_clsfr(data,devents,hdr,'capFile',capFile,'freqband',[0 1 99 100],'spatialfilter','car'); % Train classifier
save(clsfrname,'clsfr');            % Save classifier
fprintf('Saving classifier to %s. \n',clsfrname);  