%% Initialisation

% Change directory
try cd(fileparts(mfilename('fullpath')));catch; end;   
% Initialise paths
try
   run ../../matlab/utilities/initPaths.m
catch
   msgbox({'Please change to the directory where this file is saved before running the rest of this code'},'Change directory'); 
end

buffhost='localhost';buffport=1972;
% Wait for the buffer to return valid header information
hdr=[];
while ( isempty(hdr) || ~isstruct(hdr) || (hdr.nchans==0) ) % wait for the buffer to contain valid data
  try 
    hdr=buffer('get_hdr',[],buffhost,buffport); 
  catch
    hdr=[];
    fprintf('Invalid header info... waiting.\n');
  end;
  pause(1);
end;

% Settings
trialDuration = 1;                  % Lenght of a trial in seconds
trlen_ms= trialDuration * 1000;     % Lenght of a trial in ms
dname  ='training_data';            % Name of the document to store data to

%% Save data
[data,devents,state]=buffer_waitData(buffhost,buffport,[],'startSet',{{'stimulus.target'} {'target' 'non-target'}},'exitSet',{'stimulus.sequence' 'stop'},'trlen_ms',trlen_ms); % Catch 1000 ms of data after the target has been presented
data = data(1:end-1); devents = devents(1:end-1);   % Remove the data caused by the exit event
save(dname, 'data', 'devents');     % Save data to file
fprintf('Saved %d epochs to %s. \n', numel(data), dname); 