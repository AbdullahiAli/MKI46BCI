%% Initialisation

% Change directory
try cd(fileparts(mfilename('fullpath')));catch; end;   
% Initialise paths
try
   run ../../matlab/utilities/initPaths.m
catch
   msgbox({'Please change to the directory where this file is saved before running the rest of this code'},'Change directory'); 
end

buffhost='localhost';buffport=1972;
% Wait for the buffer to return valid header information
hdr=[];
while ( isempty(hdr) || ~isstruct(hdr) || (hdr.nchans==0) ) % wait for the buffer to contain valid data
  try 
    hdr=buffer('get_hdr',[],buffhost,buffport); 
  catch
    hdr=[];
    fprintf('Invalid header info... waiting.\n');
  end;
  pause(1);
end;

% Set the real-time-clock to use
initgetwTime;
initsleepSec;

% Settings
clsfrname = 'classifier';           % Name of the classifier
trlen_ms=1000;                      % Lenght of a trial

% Load classifier
clsfr=load(clsfrname); 
clsfr=clsfr.clsfr;

%% Classify data
endOfExperiment = false;            % Indicator of whether the experiment is still running
endOfLetters = false;               % Indicator of whether a prediction is expected or not
while ~endOfExperiment              % Keep making predictions until the experiment ends
    % Create set of predictions
    predic = zeros(26, numel(clsfr.spKey));                             % Array to store predictions for each class for each letter
    while ~endOfLetters && ~endOfExperiment
        % Listen for events
        [data,devents,state]=buffer_waitData(buffhost,buffport,[],'startSet',{'stimulus.letter'},'trlen_ms',trlen_ms,'exitSet',{{'stimulus.target' 'stimulus.sequence'} 'stop'});
        for i = 1:numel(devents)
            % Check if the experiment has stopped
            if matchEvents(devents(i),'stimulus.sequence','stop'); endOfExperiment = true;
            % Check if a prediction is needed
            elseif matchEvents(devents(i),'stimulus.target','stop'); endOfLetters = true;
            % Check for a letter event
            elseif matchEvents(devents(i),'stimulus.letter','*'); 
                [f,fraw,p]=buffer_apply_erp_clsfr(data(i).buf,clsfr);       % Get class predictions for this letter
                index = double(devents(i).value) - 64;                      % Get the index of the letter (A = 1, B = 2, etc)
                predic(index, :) = predic(index, :) + f;                    % Add prediction values to the total for this letter
            end;
        end;
    end;
    [v, l] = min(mean(predic,1));                                       % Take the index of the lowest rated class
    [v, l] = max(predic(:, l));                                         % Take the max value of the lowest rated class
    sleepSec(1);                                                      % Sleep so the stimulus can catch up
    sendEvent('classifier.prediction', char(l+64));                     % Send prediction as a string
    endOfLetters = false;                                               % Reset for the next round of letters
end;